
INSERT INTO `customers` (customer_id,customer_name,customer_mobile,customer_email, customer_address) VALUES
    (1, 'Shadrack Anayo', 254713968063, 'shadrackanayo@gmail.com', 'Nairobi');

INSERT INTO hotel (hotel_id, hotel_address, hotel_description,hotel_name, hotel_type) VALUES (1, 'Kericho', '5 star', 'greenstar hotel','5 start');